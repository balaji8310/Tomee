const express = require("express");
const app = express();
const http = require("http").Server(app);
const io = require("socket.io")(http);

let waitingUser = null;

app.use(express.static("public"));

io.on("connection", socket => {
  console.log("User connected:", socket.id);

  if (waitingUser) {
    socket.emit("match", waitingUser.id);
    waitingUser.emit("match", socket.id);
    waitingUser = null;
  } else {
    waitingUser = socket;
  }

  socket.on("signal", data => {
    io.to(data.to).emit("signal", {
      from: socket.id,
      signal: data.signal,
    });
  });

  socket.on("disconnect", () => {
    if (waitingUser && waitingUser.id === socket.id) {
      waitingUser = null;
    }
  });
});

http.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
